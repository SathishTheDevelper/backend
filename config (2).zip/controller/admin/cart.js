const express = require("express");
const Cart = require("../../models/Cart");

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require("express-async-handler");
const ValidateMongoId = require("../../utils/ValidateId");
const Product = require("../../models/Product");
const ProductSpeceification = require("../../models/ProductSpeceification");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
Router.get(
  "/getCart",
  asyncHandler(async (req, res) => {
    try {
      let AllCartData = await Cart.find();
          
               let list = await Promise.all(
                 AllCartData.map(async (e) => {
                   let product = await ProductSpeceification.findById(
                     e._doc.product_id
                   )
                     .populate("brand category tax")
                     .exec();

                
                   return {
                     ...e._doc,
                     product: product,
                   };
                 })
               );
         
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
         list
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);

Router.post(
  "/addCart",
  asyncHandler(async (req, res) => {
    try {
      let addCart = await Cart.create(req.body);
      return Response.success(
        res,
        200,
        true,
        "Data Added Successfully",
        addCart
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.put(
  "/editCart/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let edidCart = await Cart.findByIdAndUpdate(id, req.body, { new: true });
      return Response.success(
        res,
        200,
        true,
        "Data Updated Successfully",
        edidCart
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.delete(
  "/deleteCart/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let deleteCart = await Cart.findByIdAndDelete(id);
      console.log(deleteCart);
      if (!deleteCart) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(res, 200, true, "Data Deleted Successfully");
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.get(
  "/viewCart/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let viewCart = await Cart.findById(id);
      if (!viewCart) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(
        res,
        200,
        true,
        "Get Detail Successfully",
        viewCart
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

module.exports = Router;
