const express = require('express');
const MasterSettingDetail = require('../../models/MasterSettingDetail');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');
const UPLOAD = require("../../utils/fileUplodad");


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getMasterSettingDetail', asyncHandler( async  (req, res)=> {
     try{
         let AllMasterSettingDetailData= await MasterSettingDetail.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllMasterSettingDetailData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addMasterSettingDetail',UPLOAD.single('image'), asyncHandler (  async  (req, res)=> {
    let image=req.file?req.file.path:''
    let data={...req.body,image:image}
        
     try{
         let addMasterSettingDetail= await MasterSettingDetail.create(data)
         return Response.success( res, 200, true,"Data Added Successfully",addMasterSettingDetail);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editMasterSettingDetail/:id',UPLOAD.single('image'), asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
       let image =req.file? req.file.path :req.body.image
       console.log(image)
       let data = { ...req.body, image: image };

    try{
       let data = { ...req.body, image: image };
        let edidMasterSettingDetail= await MasterSettingDetail.findByIdAndUpdate(id,data,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully",edidMasterSettingDetail);

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteMasterSettingDetail/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteMasterSettingDetail= await MasterSettingDetail.findByIdAndDelete(id)
        console.log(deleteMasterSettingDetail)
        if(!deleteMasterSettingDetail) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewMasterSettingDetail/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewMasterSettingDetail= await MasterSettingDetail.findById(id)
         if(!viewMasterSettingDetail) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewMasterSettingDetail);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;