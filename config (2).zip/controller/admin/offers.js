const express = require('express');
const Offer = require('../../models/Offer');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getOffer', asyncHandler( async  (req, res)=> {
     try{
         let AllOfferData= await Offer.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllOfferData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addOffer', asyncHandler (  async  (req, res)=> {
     try{
         let addOffer= await Offer.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addOffer);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editOffer/:id', asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
    try{
        let edidOffer= await Offer.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully");

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteOffer/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteOffer= await Offer.findByIdAndDelete(id)
        console.log(deleteOffer)
        if(!deleteOffer) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewOffer/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewOffer= await Offer.findById(id)
         if(!viewOffer) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewOffer);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;