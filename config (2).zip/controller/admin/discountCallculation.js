const express = require("express");
const Distance = require("../../models/Distance");
const axios = require("axios");

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require("express-async-handler");
const ValidateMongoId = require("../../utils/ValidateId");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
 const gp1 =
   "https://maps.googleapis.com/maps/api/distancematrix/json?origins=";
 const gp2 = "&destinations=";
 const gp3 = "&units=imperial&key=";

 Router.post(
   "/",
   asyncHandler(async (req, res) => {
     try {
       let data1 = await Distance.find();
           let buyeraddress = "chennai";
           let pincode = "Coimbatore";
           let Weight = 1;
           const config = {
             method: "get",
             url: `${gp1}${buyeraddress}${gp2}${pincode}${gp3}${"AIzaSyCTUjetIsCddN0oXpesn8Ba-lVjsMTTdjQ"}`,
             headers: {},
           };

           await axios(config).then((response) => {
             let distance = JSON.stringify(
               response.data.rows[0].elements[0].distance.text
             );
             let str = distance;
             // str = str.substring(0, str.length -3);
             // str = str.slice(0, 1)
             str = str.slice(1, -4);

             str = parseFloat(str.replace(/,/g, ""));
             let kms = str * 1.60934;
             kms = kms.toString();
             kms = Math.round(kms);

             let dist;
             if (kms <= 100) {
               dist = "Local";
             } else if (kms >= 101 && kms <= 200) {
               dist = "Upto200Kms";
             } else if (kms >= 201 && kms <= 1000) {
               dist = "Kms201_1000";
             } else if (kms >= 1001 && kms <= 2000) {
               dist = "Kms1001_2000";
             } else if (kms >= 2001) {
               dist = "Above2000Kms";
             }

             let weight = 1;
             if (weight == "" || weight == null) {
               return res.send("Undefined");
             }
             let nameArray = data1.map(async function (el) {
               return await el.VolumeEnd;
             });
             const closest = nameArray.reduce((a, b) => {
               return Math.abs(a - weight) < Math.abs(b - weight) ? a : b;
             });
             var result = data1.find(
               async (item) => (await item.VolumeEnd) == closest
             );
             return res.send(result[dist]);
           });
       
    //    return Response.success(
    //      res,
    //      200,
    //      true,
    //      "Data Added Successfully",
    //      addDistance
    //    );
     } catch (err) {
       throw new Error(err);
     }
   })
 );
Router.get(
  "/getDistance",
  asyncHandler(async (req, res) => {
    try {
      let AllDistanceData = await Distance.find();
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
        AllDistanceData
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);


Router.post(
  "/addDistance",
  asyncHandler(async (req, res) => {
    try {
      let addDistance = await Distance.create(req.body);
      return Response.success(
        res,
        200,
        true,
        "Data Added Successfully",
        addDistance
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.put(
  "/editDistance/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let edidDistance = await Distance.findByIdAndUpdate(id, req.body, { new: true });
      return Response.success(
        res,
        200,
        true,
        "Data Updated Successfully",
        edidDistance
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.delete(
  "/deleteDistance/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let deleteDistance = await Distance.findByIdAndDelete(id);
      console.log(deleteDistance);
      if (!deleteDistance) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(res, 200, true, "Data Deleted Successfully");
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.get(
  "/viewDistance/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let viewDistance = await Distance.findById(id);
      if (!viewDistance) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(
        res,
        200,
        true,
        "Get Detail Successfully",
        viewDistance
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

module.exports = Router;
