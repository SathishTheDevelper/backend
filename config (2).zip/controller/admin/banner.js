const express = require("express");
const Banner = require("../../models/Banner");

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require("express-async-handler");
const ValidateMongoId = require("../../utils/ValidateId");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
Router.get(
  "/getBanner",
  asyncHandler(async (req, res) => {
    try {
      let AllBannerData = await Banner.find();
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
        AllBannerData
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);

Router.post(
  "/addBanner",
  asyncHandler(async (req, res) => {
    try {
      let addBanner = await Banner.create(req.body);
      return Response.success(
        res,
        200,
        true,
        "Data Added Successfully",
        addBanner
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.put(
  "/editBanner/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let edidBanner = await Banner.findByIdAndUpdate(id, req.body, { new: true });
      return Response.success(
        res,
        200,
        true,
        "Data Updated Successfully",
        edidBanner
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.delete(
  "/deleteBanner/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let deleteBanner = await Banner.findByIdAndDelete(id);
      console.log(deleteBanner);
      if (!deleteBanner) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(res, 200, true, "Data Deleted Successfully");
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.get(
  "/viewBanner/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let viewBanner = await Banner.findById(id);
      if (!viewBanner) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(
        res,
        200,
        true,
        "Get Detail Successfully",
        viewBanner
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

module.exports = Router;
