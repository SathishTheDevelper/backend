const express = require('express');
const SpeceificationDetail = require('../../models/SpeceificationDetail');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getSpeceificationDetail', asyncHandler( async  (req, res)=> {
     try{
         let AllSpeceificationDetailData= await SpeceificationDetail.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllSpeceificationDetailData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addSpeceificationDetail', asyncHandler (  async  (req, res)=> {
     try{
         let addSpeceificationDetail= await SpeceificationDetail.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addSpeceificationDetail);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editSpeceificationDetail/:id', asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
    try{
        let edidSpeceificationDetail= await SpeceificationDetail.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully",edidSpeceificationDetail);

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteSpeceificationDetail/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteSpeceificationDetail= await SpeceificationDetail.findByIdAndDelete(id)
        console.log(deleteSpeceificationDetail)
        if(!deleteSpeceificationDetail) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewSpeceificationDetail/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewSpeceificationDetail= await SpeceificationDetail.findById(id)
         if(!viewSpeceificationDetail) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewSpeceificationDetail);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;