const express = require("express");
const Payment = require("../../models/Payment");
const Cart = require("../../models/Cart");
// const Order = require("../../models/Tax");

const ProductSpeceification = require("../../models/ProductSpeceification");

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require("express-async-handler");
const ValidateMongoId = require("../../utils/ValidateId");
const financialYear = require("../../utils/financialyear");
const initiatePayment = require("../../Easebus/PaymentGetWay");
const Order = require("../../models/Order");



const project = {
  createdAt: 0,
  updatedAt: 0,
};
  
 let success = async (data, res) => {
    try {
      let obj = await response(data);
      await placeOrder(obj.data);
      res.redirect(
        `${process.env.app}profile/my-order?msg=Order placed successfully&status=${obj.data?.status}`
      );
      return obj;
    } catch (error) {
      throw error;
    }
  };
   let failure = async (data, res) => {
     try {
       let obj = await response(data);
       await obj.data;
       res.redirect(
         `${process.env.app}profile/my-order?msg=Order placed successfully&status=${obj.data?.status}`
       );
       return obj;
     } catch (error) {
       throw error;
     }
   };

   let response= async(data)=>{
       try {
         await paymentResponseLogModel.create(data);
         return await Payment.findByIdAndUpdate({_id:data.txnid},
           {
             easepayid: data.easepayid,
             status: data.status,
             cancellation_reason: data.cancellation_reason,
             error_Message: data.error_Message,
             key: data.key,
             response: JSON.stringify(data),
           },
           
         );
       } catch (error) {
         throw new Error(error);
       }
   }
   const placeOrder = async (data) => {
       try {
         let check = await Order.find({ payment_id: data._id });
         if (check) {
           throw error("Already order placed");
         }

         let date = new Date();
         let delivery_address = await Address.find({
           buyer: data.buyer,
           delivery: true,
         });

         for (let e of data.item) {
           let ord = await getOrderNo(date);
           let total = Math.round(e.qty * e.product.sp);
           let product = [
             {
               product: e.product._id,
               description: e.description,
               quantity: e.qty,
               images: e.images,
               mrp: e.mrp,
               sku: e.sku,
               selling_price: e.sp,
               discount_percentage: e.discount_percentage,
               total: e.total,
             },
           ];
           let order = await Order.create({
             payment_id: data._id,
             buyer: data.buyer,
             order_no: ord.order_no,
             financial_year: ord.financial_year,
             date: date,
             delivery_address: delivery_address,
             products: product,
             images: e.images,
             sku: e.sku,
             total: e.total,
             no_of_items: 1,
           });
         }
         return {
           success: true,
           message: "Order placed successfully.",
         };
       } catch (error) {
         throw error;
       }
     };
    const getOrderNo = async(date)=> {
    try {
      let order_no = 1;
      let financial_year = financialYear(date);
      let check = await Order
        .findOne({
          financial_year: financial_year,
        })
        .sort({ order_no: -1 });
      if (check) order_no += check.order_no;
      return {
        order_no: order_no,
        financial_year: financial_year,
      };
    } catch (error) {
      throw error;
    }
  }
   
Router.get(
  "/getPayment",
  asyncHandler(async (req, res) => {
    try {
      let AllPaymentData = await Payment.find();
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
        AllPaymentData
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);
Router.get(
  "/success",
  asyncHandler(async (req, res) => {
      try {
    
        if (req.body.status == "success") await success(req.body, res);
        else await failure (req.body, res);
      } catch (error) {
        throw new Error(error)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);
Router.get(
  "/failure",
  asyncHandler(async (req, res) => {
    try {
      let AllPaymentData = await Payment.find();
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
        AllPaymentData
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);

Router.post(
  "/addPayment",
  asyncHandler(async (req, res) => {
    try {
        let cartList = await Cart.find();
         if (cartList.length == 0) {
           throw new Error("No item(s) in cart");
         }
            let list = await Promise.all(
              cartList.map(async (e) => {
                let product = await ProductSpeceification.findById(
                  e._doc.product_id
                )
                  .populate("brand category tax")
                  .exec();

                return {
                  ...e._doc,
                  product: product,
                };
              })
            );
         let product = [];
         for (let e of list) {
           console.log(e)

           let total = Math.round(e.qty * e.product.sp + e.delivery * e.qty);
           console.log(total)
           // let dtotal = Math.round(e.product.delivery_charge.local + e.product.sp)
           // let total = Math.round(e.quantity * dtotal);
           product.push({
             product: e.product._id,
             description: e.product.description,
             quantity: e.qty,
             mrp: e.product.mrp,
             selling_price: e.product.sp,
             discount_percentage: 0,
             total: total,
           });
         }
           let data = {
             buyer: "644219605973427fe6d24c56",
             item: product,
             amount: Math.round(product.reduce((c, e) => (c += e.total), 0)),
             name: "Sathish",
             mobile_no: "6382739635",
             email: "sathish@gmail.com",
           };
      let addPayment = await Payment.create(data);
      let res = await initiatePayment(addPayment);
      return Response.success(
        res,
        200,
        true,
        "Data Added Successfully",
        addPayment
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.put(
  "/editPayment/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let edidPayment = await Payment.findByIdAndUpdate(id, req.body, { new: true });
      return Response.success(
        res,
        200,
        true,
        "Data Updated Successfully",
        edidPayment
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.delete(
  "/deletePayment/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let deletePayment = await Payment.findByIdAndDelete(id);
      console.log(deletePayment);
      if (!deletePayment) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(res, 200, true, "Data Deleted Successfully");
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.get(
  "/viewPayment/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let viewPayment = await Payment.findById(id);
      if (!viewPayment) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(
        res,
        200,
        true,
        "Get Detail Successfully",
        viewPayment
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

module.exports = Router;
