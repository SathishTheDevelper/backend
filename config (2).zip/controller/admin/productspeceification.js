const express = require("express");
const ProductSpeceification = require("../../models/ProductSpeceification");

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require("express-async-handler");
const ValidateMongoId = require("../../utils/ValidateId");
const UPLOAD = require("../../utils/fileUplodad");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
Router.get(
  "/getProductSpeceification",
  asyncHandler(async (req, res) => {
    let query={}
     if (req.query.product) {
       query.product = req.query.product;
     }
    if(req.query.brand){
         query.brand = req.query.brand;
    }
      if (req.query.category) {
        query.category = req.query.category
      }
    try {
      let AllProductSpeceificationData = await ProductSpeceification.find(
        query
      ).populate("category brand").exec();
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
        AllProductSpeceificationData
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);

Router.post(
  "/addProductSpeceification",UPLOAD.array('files'),
  asyncHandler(async (req, res) => {
     const reqFiles = [];
     if (req.files)
       for (var i = 0; i < req.files.length; i++) {
         reqFiles.push({
           path: req.files[i].path,
         });
       }
       const data = { ...req.body, images: reqFiles };
    try {
      let addProductSpeceification = await ProductSpeceification.create(data);
      return Response.success(
        res,
        200,
        true,
        "Data Added Successfully",
        addProductSpeceification
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.put(
  "/editProductSpeceification/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let edidProductSpeceification = await ProductSpeceification.findByIdAndUpdate(id, req.body, {
        new: true,
      });
      return Response.success(
        res,
        200,
        true,
        "Data Updated Successfully",
        edidProductSpeceification
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.delete(
  "/deleteProductSpeceification/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let deleteProductSpeceification = await ProductSpeceification.findByIdAndDelete(id);
      console.log(deleteProductSpeceification);
      if (!deleteProductSpeceification) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(res, 200, true, "Data Deleted Successfully");
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.get(
  "/viewProductSpeceification/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let viewProductSpeceification = await ProductSpeceification.findById(id);
      if (!viewProductSpeceification) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(
        res,
        200,
        true,
        "Get Detail Successfully",
        viewProductSpeceification
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

module.exports = Router;
