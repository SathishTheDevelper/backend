const express = require('express');
const Speceification = require('../../models/Specefication');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');
const ValidateMongoId = require('../../utils/ValidateId');


const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getSpeceification', asyncHandler( async  (req, res)=> {
     try{
         let AllSpeceificationData= await Speceification.find()
         return Response.success( res, 200, true,"Get Details Successfully",AllSpeceificationData);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addSpeceification', asyncHandler (  async  (req, res)=> {
     try{
         let addSpeceification= await Speceification.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addSpeceification);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editSpeceification/:id', asyncHandler( async (req, res)=> {
      const {id}=req?.params
      ValidateMongoId(id)
    try{
        let edidSpeceification= await Speceification.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully",edidSpeceification);

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteSpeceification/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let deleteSpeceification= await Speceification.findByIdAndDelete(id)
        console.log(deleteSpeceification)
        if(!deleteSpeceification) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewSpeceification/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    ValidateMongoId(id)
    try{
        let viewSpeceification= await Speceification.findById(id)
         if(!viewSpeceification) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewSpeceification);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;