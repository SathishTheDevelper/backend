const express = require("express");
const Product = require("../../models/Product");
const ProductSpeceification = require("../../models/ProductSpeceification");

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require("express-async-handler");
const ValidateMongoId = require("../../utils/ValidateId");

const project = {
  createdAt: 0,
  updatedAt: 0,
};
Router.get(
  "/getProduct",
  asyncHandler(async (req, res) => {

    try {
      let AllProductData = await Product.find();
      let data=[]
      for(var i=0;i<AllProductData.length ;i++ ){
         let data1 = await ProductSpeceification.find( {product:AllProductData[i]._id});

         console.log(data)
      }
    
      return Response.success(
        res,
        200,
        true,
        "Get Details Successfully",
        AllProductData
      );
    } catch (err) {
      throw new Error(err);
    }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
  })
);

Router.post(
  "/addProduct",
  asyncHandler(async (req, res) => {
    try {
      let addProduct = await Product.create(req.body);
      return Response.success(
        res,
        200,
        true,
        "Data Added Successfully",
        addProduct
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.put(
  "/editProduct/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let edidProduct = await Product.findByIdAndUpdate(id, req.body, {
        new: true,
      });
      return Response.success(
        res,
        200,
        true,
        "Data Updated Successfully",
        edidProduct
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.delete(
  "/deleteProduct/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let deleteProduct = await Product.findByIdAndDelete(id);
      console.log(deleteProduct);
      if (!deleteProduct) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(res, 200, true, "Data Deleted Successfully");
    } catch (err) {
      throw new Error(err);
    }
  })
);

Router.get(
  "/viewProduct/:id",
  asyncHandler(async (req, res) => {
    const { id } = req?.params;
    ValidateMongoId(id);
    try {
      let viewProduct = await Product.findById(id);
      if (!viewProduct) throw new Error(`Resource Not Found this id : ${id}`);
      return Response.success(
        res,
        200,
        true,
        "Get Detail Successfully",
        viewProduct
      );
    } catch (err) {
      throw new Error(err);
    }
  })
);

module.exports = Router;
