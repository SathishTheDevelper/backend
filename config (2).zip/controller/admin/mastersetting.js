const express = require('express');
const Mastersetting = require('../../models/Mastersetting');
const MastersettingDetail = require('../../models/MasterSettingDetail');

const Router = express.Router();
const Response = require("../../utils/response");
const asyncHandler = require('express-async-handler');

const project = {
    createdAt: 0,
    updatedAt: 0,
}
Router.get('/getMastersetting', asyncHandler( async  (req, res)=> {
    console.log(req.originalUrl)
     let query={}
      if(req.query.mode){query.mode=req.query.mode}
     try{
         var AllMastersettingData = await Mastersetting.find(query)
           .populate("parent_id",'name mode').exec();
         console.log(AllMastersettingData)
         let AllMastersettingDetail= await MastersettingDetail.find()
         console.log(AllMastersettingDetail)
         const data = [];
          for(var i=0; i<AllMastersettingData.length; i++){
              data.push({
                _id: AllMastersettingData[i]._id,
                name: AllMastersettingData[i].name,
                mode: AllMastersettingData[i].mode,
                parent_id:AllMastersettingData[i].parent_id?AllMastersettingData[i].parent_id:null,
                details: await MastersettingDetail.find({
                  parent_id: AllMastersettingData[i]._id,
                })
                  .select("description image -_id")
                  .exec(),
              });
          }
            
    
                  
        
       
          
         return Response.success( res, 200, true,"Get Details Successfully",data);
     }
      catch(err){
         throw new Error(err)
      }

    //middleware 1st =>product access=> optionload 1,2,3,4,5
    
 
}));

Router.post('/addMastersetting', asyncHandler (  async  (req, res)=> {
     try{
         let addMastersetting= await Mastersetting.create(req.body)
         return Response.success( res, 200, true,"Data Added Successfully",addMastersetting);

     }
      catch(err){
         throw new Error(err)
      }

}));


Router.put('/editMastersetting/:id', asyncHandler(  async (req, res)=> {
      const {id}=req?.params
       
    try{
        let edidMastersetting= await Mastersetting.findByIdAndUpdate(id,req.body,{new:true})
        return Response.success( res, 200, true,"Data Updated Successfully",edidMastersetting);

    }
     catch(err){
        throw new Error(err)
     }


}));

Router.delete('/deleteMastersetting/:id', asyncHandler( async  (req, res)=> {
    const {id}=req?.params
    try{
        let deleteMastersetting= await Mastersetting.findByIdAndDelete(id)
        console.log(deleteMastersetting)
        if(!deleteMastersetting) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Data Deleted Successfully");

    }
     catch(err){
        throw new Error(err)
     }
   
}));

Router.get('/viewMastersetting/:id',asyncHandler( async (req, res,)=> {
    const {id}=req?.params
    try{
        let viewMastersetting= await Mastersetting.findById(id)
         if(!viewMastersetting) throw new Error(`Resource Not Found this id : ${id}`)
        return Response.success( res, 200, true,"Get Detail Successfully",viewMastersetting);

    }
     catch(err){
        throw new Error(err)
     }
   
}));


module.exports = Router;