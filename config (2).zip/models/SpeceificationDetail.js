const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var SpeceificationDetailSchema = new mongoose.Schema(
   {
    company_code: { type: Schema.Types.ObjectId, ref: "master-users" },
    name:{
         type:String,
         required:true
    },
    parent_id:{ type: Schema.Types.ObjectId, ref: "Speceification" },
    status: {
      type: Boolean,
    },
    doneby:{ type: Schema.Types.ObjectId, ref: "master-users" }
   }
   
   ,{
    timestamps: true,
    versionKey: false,
  }
)




module.exports = mongoose.model("SpeceificationDetail",SpeceificationDetailSchema );