const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var OrderSchema = new mongoose.Schema(
  {
    buyer: { type: mongoose.Schema.Types.ObjectId, ref: "buyer" },
    payment_id: { type: mongoose.Schema.Types.ObjectId, ref: "payment" },
    order_no: { type: Number, required: true },
    financial_year: { type: String, required: true },
    date: { type: Date, default: Date.now },
    delivery_address: {

    },
    products: [
          { product: { type: mongoose.Schema.Types.ObjectId, ref: "product" },
    description: String,
    quantity: { type: Number, required: true, min: 1 },
    mrp: { type: Number, required: true },
    sp: { type: Number, required: true },
    discount_percentage: { type: Number },
    total: { type: Number },
  }],
    total: Number,
    no_of_items: Number,
    cancel: { type: Boolean, default: false },
    status: {
      type: String,
      default: "Pending",
      enum: [
        "Pending",
        "Packing",
        "Billed",
        "Dispatched",
        "Delivered",
        "Cancel",
      ],
    },
    doneby: { type: Schema.Types.ObjectId, ref: "master-users" },
  },

  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("Order", OrderSchema);