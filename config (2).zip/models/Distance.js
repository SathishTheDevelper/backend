const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var DistanceSchema = new mongoose.Schema(
  {
    Local: { type: String, required: true },
    Above2000Kms: { type: String, required: true },
    Upto200Kms: { type: String, required: true },
    Kms1001_2000: { type: String, required: true },
    Kms201_1000: { type: String, required: true },
    VolumeStart: { type: String, required: true },
    VolumeEnd: { type: String, required: true },
    status: { type: Boolean, default: true },
    doneby: { type: Schema.Types.ObjectId, ref: "master-users" },
  },

  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("Distance", DistanceSchema);
