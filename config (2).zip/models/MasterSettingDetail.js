const mongoose = require("mongoose");
var Schema = mongoose.Schema;



var MasterSettingDetailSchema = new mongoose.Schema(
   {
     image:String,
     description:String,
     parent_id:{ type: Schema.Types.ObjectId, ref: "Mastersetting", requird:true},
    done_by:{ type: Schema.Types.ObjectId, ref: "master-users" },
   }
   

);




module.exports = mongoose.model("MasterSettingDetail",MasterSettingDetailSchema );