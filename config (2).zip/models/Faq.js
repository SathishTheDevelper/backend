const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

var FaqSchema = new mongoose.Schema(
   {
    name: {type:String, required:true, unique:true},
   }
   

);




module.exports = mongoose.model("Faq",FaqSchema );