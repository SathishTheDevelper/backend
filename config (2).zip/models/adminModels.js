const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

var adminSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    companyname: {
      type: String,
      require: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    phone: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
      trim: true,
    },
    role: {
      type: String,
      require: true,
      default: "admin",
      trim: true,
    },
    isblocked: {
      type: Boolean,
      default: false,
      selected: false,
      trim: true,
    },
    companycode: {
      type: String,
      require: true,
      unique: true,
      trim: true,
    },
    status: {
      type: String,
      default: 1,
      selected: false,
    },
  },
  {
    timestamps: true,
  }
);

adminSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    next();
  }
  const salt = await bcrypt.genSaltSync(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

adminSchema.methods.isPasswordMatched = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword,this.password);
}


module.exports = mongoose.model("Admin", adminSchema);
