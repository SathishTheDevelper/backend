const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var ProductSchema = new mongoose.Schema(
  {
    brand: { type: mongoose.Schema.Types.ObjectId, ref: "Mastersetting" },
    category: [{ type: Schema.Types.ObjectId, ref: "Mastersetting" }],
    image: String,
    description: String,
    productname: String,

    status: { type: Boolean, default: true },
    done_by: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
    publish: { type: Boolean, default: false },
    doneby: { type: Schema.Types.ObjectId, ref: "master-users" },
  },

  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("Product", ProductSchema);
