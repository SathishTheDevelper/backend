const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var CartSchema = new mongoose.Schema(
  {
    company_code: { type: Schema.Types.ObjectId, ref: "master-users" },
    buyer_id: { type: Schema.Types.ObjectId, ref: "users" },
    product_id: { type: Schema.Types.ObjectId, ref: "ProductSpeceification" },
    delivery: { type: Number, default: 0 },
    qty: { type: Number, default: 1 },

    status: { type: Boolean, default: true },
    doneby: { type: Schema.Types.ObjectId, ref: "master-users" },
  },

  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("Cart", CartSchema);
