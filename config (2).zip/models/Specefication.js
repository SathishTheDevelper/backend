const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var SpeceificationSchema = new mongoose.Schema(
   {
    name: { type: String, required: true },
    company_code: { type: Schema.Types.ObjectId, ref: "master-users" },
    status: {
      type: Boolean,
      default: true,
    },

    doneby:{ type: Schema.Types.ObjectId, ref: "master-users" }
   }
   
   ,{
    timestamps: true,
    versionKey: false,
  }
)




module.exports = mongoose.model("Speceification",SpeceificationSchema );