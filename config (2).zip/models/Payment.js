const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var PaymentSchema = new mongoose.Schema(
  {
    buyer: { type: mongoose.Schema.Types.ObjectId, ref: "buyer" },
    item: [
      {
        product: { type: mongoose.Schema.Types.ObjectId, ref: "product" },
        description: String,
        quantity: { type: Number, required: true, min: 1 },
        mrp: { type: Number, required: true },
        selling_price: { type: Number, required: true },
        discount_percentage: { type: Number },
        total: { type: Number },
      },
    ],
    amount: Number,
    name: String,
    mobile_no: String,
    email: String,
    easepayid: String,
    status: String,
    cancellation_reason: String,
    error_Message: String,
    key: String,
    response: String,
    doneby: { type: Schema.Types.ObjectId, ref: "master-users" },
  },

  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("Payment", PaymentSchema);
