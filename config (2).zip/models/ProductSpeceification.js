const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
var Schema = mongoose.Schema;

var ProductSpeceificationSchema = new mongoose.Schema(
  {
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
      required: true,
    },
    mrp: {
        type:Number,
        required:true 
    },
    brand: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Mastersetting",
      required: true,
    },
    category: [{ type: Schema.Types.ObjectId, ref: "Mastersetting", required:true  },  ],
    sp: {
        type:Number,
        required:true 
    },
    stock: Number,
    hsn_code: String,
    discount: Object,
    specification: [],
    meta_desc: String,
    meta_key: String,
    highlight: [String],
    key_words: [String],
    delivery_days: Number,
    description: String,
    images: [{ path: String }],

    sku: { type: String, trim: true, unique: true, uppercase: true },
    model: { type: String, trim: true, uppercase: true },

    display_date: Date,
    min_order_qty: Number,

    note: String,

    packing_detail: {
      weight: Number,
      length: Number,
      breadth: Number,
      height: Number,
    },
    delivery_charge: {
      local: Number,
      zonal: Number,
      national: Number,
    },

    tax: { type: mongoose.Schema.Types.ObjectId, ref: "Tax" },
    offer: { type: mongoose.Schema.Types.ObjectId, ref: "Offer" },
    done_by: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
  },

  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = mongoose.model("ProductSpeceification", ProductSpeceificationSchema);
