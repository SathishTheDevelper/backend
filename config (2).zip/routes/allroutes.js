const BaseUrl = '/api/v1/';
  module.exports = function (app) {
    app.use(BaseUrl + "faq", require("../controller/admin/faq"));
    // app.use(BaseUrl + "accessmodule", require("../controller/admin/accessmodule"));
    // app.use(
    //   BaseUrl + "accessmenu",
    //   require("../controller/admin/accessmenu")
    // );
    // app.use(BaseUrl + "banner", require("../controller/admin/banner"));
    // app.use(BaseUrl + "plan", require("../controller/admin/subscription"));
    // app.use(BaseUrl + "menu", require("../controller/admin/menuMaster"));
    // app.use(BaseUrl + "masteruser", require("../controller/admin/masterUser"));
    // app.use(BaseUrl + "hiredplan",require("../controller/admin/hiredplan"));
    // app.use(BaseUrl + "sellerinfo",require("../controller/admin/sellerinfo"));
    // app.use(BaseUrl + "accessetting", require("../controller/admin/accessetting"));
    // app.use(BaseUrl + "users", require("../controller/admin/users"));
     app.use(BaseUrl + "tax", require("../controller/admin/tax"));
    // app.use(BaseUrl + "damageinfo", require("../controller/admin/damageinfo"));
     app.use(BaseUrl + "offers", require("../controller/admin/offers"));
    // app.use(BaseUrl + "offerrules", require("../controller/admin/ofeerrules"));
    // app.use(BaseUrl + "wishlist", require("../controller/admin/wishlist"));
     app.use(BaseUrl + "cart", require("../controller/admin/cart"));
    // app.use(BaseUrl + "inventary", require("../controller/admin/inventary"));
    // app.use(BaseUrl + "production", require("../controller/admin/production"));
    // app.use(BaseUrl + "orderinfo", require("../controller/admin/order"));
    // app.use(BaseUrl + "returninfo", require("../controller/admin/returninfo"));
    // app.use(BaseUrl + "paymentinfo", require("../controller/admin/paymentinfo"));
    // app.use(
    //   BaseUrl + "purchase",
    //   require("../controller/admin/purcahaseinfo")
    // );
    // app.use(
    //   BaseUrl + "bill",
    //   require("../controller/admin/bill")
    // );
      app.use(
        BaseUrl + "distance",
        require("../controller/admin/discountCallculation")
      );
       app.use(
         BaseUrl + "payment",
         require("../controller/admin/payment")
       );
    // app.use(BaseUrl + "dispatchinfo", require("../controller/admin/dispatchinfo")); 
    // app.use(
    //   BaseUrl + "deliveryinfo",
    //   require("../controller/admin/deliveryinfo")
    // ); 
    // app.use(BaseUrl + "pakinginfo", require("../controller/admin/pakinginfo"));
    // app.use(BaseUrl + "buyerregister", require("../controller/admin/buyerregister"));
    // app.use(
    //   BaseUrl + "buyerbillings",
    //   require("../controller/admin/buyerbilling")
    // );
    // app.use(BaseUrl + "offeraplicables", require("../controller/admin/offeraplicable"));
    // app.use(BaseUrl + "offeraplicables", require("../controller/admin/offeraplicable"));
    // app.use(BaseUrl + "discound", require("../controller/admin/discounts"));
    // app.use(BaseUrl + "discountrules", require("../controller/admin/discoundrules"));
    // app.use(
    //   BaseUrl + "discountapplicable",
    //   require("../controller/admin/discountapplicapleproducts")
    // );
     app.use(BaseUrl + "product", require("../controller/admin/product"));
    app.use(BaseUrl + "productspeceification", require("../controller/admin/productspeceification"))
    // app.use(BaseUrl + "productimages", require("../controller/admin/proudctimages"));
    // app.use(BaseUrl + "productvideo", require("../controller/admin/productvedio"));
    // app.use(
    //   BaseUrl + "productrate",
    //   require("../controller/admin/productrate")
    // );

    // app.use(
    //   BaseUrl + "productseo",
    //   require("../controller/admin/productseo")
    // );
    app.use(BaseUrl + "mastersetting", require("../controller/admin/mastersetting"));
    // // app.use(BaseUrl + "mastersetting", require("../controller/admin/mastersetting"));
     app.use(
      BaseUrl + "mastersettingdetail",
      require("../controller/admin/mastersettingDeatil")
    );
    app.use(
      BaseUrl + "speceification",
      require("../controller/admin/specefication")
    );
      app.use(
        BaseUrl + "speceificationdetail",
        require("../controller/admin/speceificationdetail")
      );
    //    app.use(
    //      BaseUrl + "admin",
    //      require("../controller/admin/admins")
    //    );

    //     app.use(BaseUrl + "admin", require("../controller/frontend/dynmaic"));
    //     app.use(BaseUrl + "home", require("../controller/frontend/home"));   
    //     app.use(BaseUrl + "template", require("../controller/frontend/template"));  
    //     app.use(
    //       BaseUrl + "enquiry",
    //       require("../controller/frontend/enquiry")
    //     );  




      //  Front end websites

    
  
}
